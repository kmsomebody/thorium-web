To create a release:
pnpm run bundle
pnpm pack


Then manually upload it to github